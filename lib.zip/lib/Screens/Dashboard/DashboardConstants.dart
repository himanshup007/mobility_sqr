

import 'package:flutter/cupertino.dart';

FontWeight customWeight=FontWeight.w700;