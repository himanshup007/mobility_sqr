import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobility_sqr/Constants/AppConstants.dart';
import 'package:mobility_sqr/ModelClasses/PerDiemModelClass.dart';
import 'package:sizer/sizer.dart';

import 'package:flutter/cupertino.dart';

import 'package:mobility_sqr/ModelClasses/AddReqPayLoad.dart';

class CurrencyClass extends StatefulWidget {


  CurrencyClass();

  @override
  _CurrencyClassState createState() => _CurrencyClassState();
}

class _CurrencyClassState extends State<CurrencyClass> {
  @override


  _CurrencyClassState();

  Widget build(BuildContext context) {

    return Container(color: Colors.red,height: 100,width: 100,);
  }

  }



