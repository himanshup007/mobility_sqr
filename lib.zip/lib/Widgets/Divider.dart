

import 'package:flutter/material.dart';

 CustomDivider(){

  return
    Divider(
      height: 0.5,
      indent: 80,
      endIndent: 30,
      thickness: 0.8,
    );
}