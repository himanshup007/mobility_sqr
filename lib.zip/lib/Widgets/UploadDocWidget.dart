
import 'package:flutter/material.dart';

class UploadDocWidget extends StatefulWidget {
  @override
  _UploadDocWidgetState createState() => _UploadDocWidgetState();
}

class _UploadDocWidgetState extends State<UploadDocWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(

    );
  }
}
